
import * as vscode from 'vscode';
//let myStatusBarItem: vscode.StatusBarItem;
//eai

export function activate(context: vscode.ExtensionContext) {

	
	console.log('Congratulations, your extension "nahmias" is now active!');

	
	let disposable = vscode.commands.registerCommand('nahmias.helloWorld', () => {
		
		vscode.window.showInformationMessage('Hello World de nahmias!');
	});
	/*myStatusBarItem = vscode.window.createStatusBarItem(
		vscode.StatusBarAlignment.Left,
		10000
	);*/
	context.subscriptions.push(disposable/*myStatusBarItem*/);
	//updateStatusBar(context);
}

/*function updateStatusBar(context: vscode.ExtensionContext): void {
	myStatusBarItem.text="Hello World!";
	myStatusBarItem.tooltip="Hello World!";
	myStatusBarItem.show();
}*/